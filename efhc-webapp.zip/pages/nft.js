import Header from '../components/Header';
import Footer from '../components/Footer';
import { useEffect, useState } from 'react';
import TonWeb from 'tonweb';
import { nftData } from '../data/nftData';

export default function NFTPage() {
  const [nfts] = useState(nftData);

  // TonWeb integration placeholder for real blockchain calls
  useEffect(() => {
    // Example: connect to TonWeb and fetch real NFT data
  }, []);

  return (
    <div>
      <Header />
      <main className="max-w-7xl mx-auto p-8">
        <h2 className="text-3xl font-semibold">NFT Коллекции</h2>
        <div className="mt-8 grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-8">
          {nfts.map((nft) => (
            <div key={nft.id} className="bg-white p-4 rounded-lg shadow-md">
              <img src={nft.imageUrl} alt={nft.name} className="w-full h-48 object-cover rounded-lg" />
              <h3 className="text-xl mt-4">{nft.name}</h3>
              <p className="mt-2 text-gray-600">{nft.description}</p>
              <button className="mt-4 bg-blue-600 text-white px-6 py-2 rounded-lg">
                Купить
              </button>
            </div>
          ))}
        </div>
      </main>
      <Footer />
    </div>
  );
}
