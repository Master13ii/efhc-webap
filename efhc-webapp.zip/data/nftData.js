export const nftData = [
  {
    id: 1,
    name: 'EFHC Token #1',
    description: 'Первый токен EFHC',
    imageUrl: '/images/logo.png'
  },
  {
    id: 2,
    name: 'EFHC Token #2',
    description: 'Второй токен EFHC',
    imageUrl: '/images/logo.png'
  }
];
